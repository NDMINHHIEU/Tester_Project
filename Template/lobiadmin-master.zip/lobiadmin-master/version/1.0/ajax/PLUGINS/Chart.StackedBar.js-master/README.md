Chart.StackedBar.js
===================

*StackedBar plugin for Chart.js* [chartjs.org](http://www.chartjs.org)

## Documentation

You can find the documentation under `/docs`

## License

Chart.StackedBar.js is available under the [MIT license](http://opensource.org/licenses/MIT).

## Bugs & issues

When reporting bugs or issues, if you could include a link to a simple [jsbin](http://jsbin.com) or similar demonstrating the issue, that'd be really helpful.
